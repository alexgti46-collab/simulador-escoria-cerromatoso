# Simulador de Escoria – Android

Proyecto Android sencillo que ejecuta el simulador offline en un WebView.

## Construcción local
Requiere JDK 17, Android SDK API 35 y Gradle 8.9:
`gradle assembleDebug`

APK: `app/build/outputs/apk/debug/app-debug.apk`

## Construcción en GitHub
Sube este proyecto a la rama `main`. El workflow `.github/workflows/build-apk.yml` compila el APK y lo publica como artefacto en GitHub Actions.

## Alcance metalúrgico y seguridad
Los umbrales incluidos son referencias provisionales editables, no consignas oficiales ni un modelo termodinámico. La app no calcula temperatura liquidus ni viscosidad: esas predicciones requieren composición completa, temperatura, estado redox y calibración con datos validados de planta. No usar para control directo del horno.
